#Calculates the Energy of an object at the speed of light
m=int(input("Enter mass of object as an integer (kg) "))


#Define variable c
c=3*10**8


#Define equation for E
E=m*c**2

#Print Output
print(E, "Joules")