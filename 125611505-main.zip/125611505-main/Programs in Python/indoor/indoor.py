name = input ("Please type input here ").lower()



print(name)