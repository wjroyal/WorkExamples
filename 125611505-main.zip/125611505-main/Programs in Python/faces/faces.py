main = str(input())
Coming="Hello :)"

Going="Goodbye :("

Both="Hello :) Goodbye :("

if main==Coming:
   print("Hello", "\U0001F642	")

elif main==Going:
   print("Goodbye", "\U0001F641	")

elif main==Both:
   print("Hello", "\U0001F642", "Goodbye", "\U0001F641")

else:
   print("Try again")

