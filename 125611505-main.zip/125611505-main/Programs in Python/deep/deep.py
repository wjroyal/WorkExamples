deep=input("What is the meaning of life?").lower().strip()

match deep:
    case "42":
        print("Yes")
    case "forty-two":
        print("Yes")
    case "forty two":
        print("Yes")
    case _:
        print("No")