a=input("Enter your sentence: ")

#Split in to n str
#print every str with ... as whitespace

a = a.split()
print(*a, sep='...')


